APEX AI — SVG interface, Free.ai direct test
- index.html is the complete single-file app. All logos and interface icons are inline SVG; no icon package or external icon images are used.
- Deploy the extracted index.html as a static site with Netlify.
- Open API settings and paste your Free.ai API key, then tap Use key for this session.
- Direct browser calls may fail if Free.ai does not permit CORS from your deployed domain. If so, use a Netlify Function instead.
- Do not commit a real private API key to public code. The `FREE_AI_API_KEY` line is for a test key only and is blank by default.
