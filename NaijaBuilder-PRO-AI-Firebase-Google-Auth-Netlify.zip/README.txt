NaijaBuilder PRO — Netlify + Firebase Authentication

PACKAGE CONTENTS
- index.html: AI chat, website builder, email/password login, registration, and Google sign-in
- netlify.toml: Netlify publish/function settings
- netlify/functions/generate.mjs: secure Gemini server function

PART A — CREATE FIREBASE PROJECT (PHONE FRIENDLY)
1. Open https://console.firebase.google.com/ and sign in with your Google account.
2. Tap Add project / Create a project. Name it NaijaBuilder PRO. Continue through the setup prompts. Analytics is optional.
3. In the project overview, tap the web icon </> to add a web app. Name it NaijaBuilder PRO Web. Register the app.
4. Firebase will show a firebaseConfig object. Keep this page open or copy the values. You will paste the values into index.html (instructions below). The web config is not a service-account secret; never paste a service account private key into this file.
5. In Firebase Console, open Build → Authentication → Get started. Open Sign-in method / Providers, select Email/Password, enable Email/Password, and save.
6. In the same Sign-in method / Providers screen, select Google, enable it, choose a support email, and save.
7. In Authentication → Settings → Authorized domains, make sure your deployed Netlify domain is authorized. Look under Settings → Authorized domains and add your site's domain if it is missing. Do not include https:// or a path, just the hostname (for example your-site.netlify.app).

PART B — PASTE FIREBASE WEB CONFIG INTO index.html
1. Open index.html in a code editor (GitHub's web editor can be used, but a phone-friendly code editor is easier).
2. Find `const firebaseConfig = {` near the bottom. Replace each placeholder with the corresponding value from the Firebase web app config object. Keep quotation marks and commas.
3. The values map as follows: apiKey → apiKey; authDomain → authDomain; projectId → projectId; storageBucket → storageBucket; messagingSenderId → messagingSenderId; appId → appId.
4. This package already includes the Firebase web config for project ai54-34fd5. If you registered a different Firebase project, replace these values with that project’s config. Save/commit index.html. These Firebase web app config values are used by the client SDK. Security comes from Firebase Authentication and secure database rules, not hiding this web config. Never add a service-account JSON file or Gemini API key to index.html.

PART C — DEPLOY TO NETLIFY
1. Upload the full package to a GitHub repository, preserving netlify/functions/generate.mjs and netlify.toml.
2. Connect that repository to Netlify, with the project root as the publish directory. netlify.toml configures functions to use netlify/functions.
3. In Netlify Project configuration → Environment variables, add GEMINI_API_KEY with your new Gemini API key from https://aistudio.google.com/apikey. Save, then redeploy. Do not put the Gemini key in GitHub or index.html.
4. Test account creation, email/password login, Continue with Google, forgot password, sign out, Chat AI and Build Web.

NOTES
- New accounts send an email verification message, but the app allows the newly created user to enter the builder immediately.
- This package uses Firebase Auth for account identity. It does not yet save a user's previous AI conversations or generated websites in a database.
- If you previously exposed a real Gemini API key publicly, revoke it and create a new one.
