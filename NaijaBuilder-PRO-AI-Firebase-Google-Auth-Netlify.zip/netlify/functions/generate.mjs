// Netlify serverless function: keeps GEMINI_API_KEY on the server.
// Endpoint: /.netlify/functions/generate
export default async (request) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Use POST for AI requests." }, { status: 405, headers: { "Allow": "POST" } });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return Response.json(
      { error: "AI is not configured yet. Add GEMINI_API_KEY under your Netlify project's environment variables, then redeploy." },
      { status: 503 }
    );
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }

  const prompt = typeof body?.prompt === "string" ? body.prompt.trim() : "";
  const task = body?.task === "build" ? "build" : "chat";
  if (!prompt) return Response.json({ error: "Please enter a prompt." }, { status: 400 });
  if (prompt.length > 18000) {
    return Response.json({ error: "Your prompt is too long. Please keep it under 18,000 characters." }, { status: 413 });
  }

  const systemInstruction = task === "build"
    ? "You generate complete, polished, responsive single-file HTML websites. Return only raw HTML beginning with <!DOCTYPE html>, without markdown fences. Include CSS and JavaScript inline where practical. Do not include API keys, passwords, or other secrets. Do not claim that payments, authentication, databases, or external services work unless implemented."
    : "You are NaijaBuilder PRO, a helpful and safe Nigerian AI assistant. Answer clearly and concisely. Use light Nigerian Pidgin only if the user does.";

  try {
    const upstream = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey
        },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemInstruction }] },
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: task === "build" ? 0.4 : 0.7,
            maxOutputTokens: task === "build" ? 12000 : 2048
          }
        })
      }
    );

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const providerMessage = result?.error?.message || "Gemini request failed.";
      const status = upstream.status === 429 ? 429 : 502;
      return Response.json(
        { error: upstream.status === 429
            ? "AI rate limit or quota reached. Check your Gemini API quota and try again later."
            : "Gemini could not complete the request: " + providerMessage },
        { status }
      );
    }

    const text = result?.candidates?.[0]?.content?.parts
      ?.map(part => typeof part.text === "string" ? part.text : "")
      .join("")
      .trim();

    if (!text) {
      return Response.json({ error: "Gemini returned no text. Try a shorter prompt." }, { status: 502 });
    }
    return Response.json({ text });
  } catch {
    return Response.json({ error: "Could not reach Gemini. Check the function logs and try again." }, { status: 502 });
  }
};
